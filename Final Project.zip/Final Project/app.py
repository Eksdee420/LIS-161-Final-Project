from flask import Flask, request, redirect, url_for, session, render_template, g
import sqlite3
app = Flask(__name__)

# Configuration
app.config["DEBUG"] = True
app.config["SECRET_KEY"] = "thisisasecretkey!"

# Database Connection
def connect_db():
    # Connects/opens database with given filename
    conn = sqlite3.connect('gamelistall.db')
    conn.row_factory = sqlite3.Row
    return conn

#Game Database Converter
def get_db():
    if not hasattr(g, 'sqlite3'):
        g.sqlite_db = connect_db()
    return g.sqlite_db

##========================================================##DELET DIS
def read_all_users_games():
    # Read all contents of game table
    conn = connect_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM "Games"')
    results = cur.fetchall()
    cur.close()
    return results
    #end of game table transaction
##========================================================##DELET DIS

#end of db transaction

#start of route
@app.route('/')
def index():
    session["username"] = ""
    return render_template('iindex.html')

@app.route('/home')
def home():
    username = session["username"]
    return render_template('home.html', username=username)

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    error = ""
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = "Invalid"
        else:
            session['username'] = request.form['username']
            return redirect(url_for('home'))
    return render_template('signin.html',error=error)

@app.route('/games', methods=['POST','GET'])

#Table of Games Page
def games():
    username = session['username']
    db = get_db()  # Retrieves database
    cur = db.execute('select id, Game, Platform, Quantity from Games')  #Get all db list
    results = cur.fetchall()
    return render_template('games.html',username=username, results=results)

#Addition of Data
@app.route('/add', methods=['POST', 'GET'])
def add():
    username = session['username'] #gets current session
    if request.method == 'GET':
        return render_template('add.html')  # Loads the add page if not posting
    if request.method == 'POST':
        Game = request.form['Game']  # retrieve game name
        Platform = request.form['Platform']  # retrieve platform
        Quantity = request.form['Quantity']  # retrieve quantity

        db = get_db()
        db.execute('insert into Games (Game,Platform,Quantity) values (?,?,?)', [Game, Platform, Quantity])  # SQL Command Insert new game
        db.commit()  # Push SQL Changes
        return render_template('home.html')
    return render_template('add.html')

#Editing Data
@app.route('/edit', methods=['POST', 'GET'])
def edit():
    username = session['username']
    if request.method == 'GET':
        return render_template('edit.html')  # Loads the edit page if not posting
    if request.method == 'POST':
        id = request.form['id'] #id of game
        Game = request.form['Game']  # retrieve game name
        Platform = request.form['Platform']  # retrieve platform
        Quantity = request.form['Quantity']  # retrieve quantity

        db = get_db()
        db.execute('update Games set Game = ?, Platform = ?, Quantity = ? where id = ?',
                   [Game, Platform, Quantity, id])  # SQL Command Edit Game row
        db.commit()  # Push SQL Changes
    return render_template('edit.html')

#Deleting Data
@app.route('/delete', methods=['POST', 'GET'])
def delete():
    username = session['username']
    if request.method == 'GET':
        return render_template('delete.html')  # Loads the delete page if not posting
    if request.method == 'POST':
        id = request.form['id']
        db = get_db()
        db.execute('delete from Games where id = ?', [id])  # SQL Command Edit assigned game row
        db.commit()  # Push SQL Changes
    return render_template('delete.html') #Loads delete page

##---------------------------------------------------------------##
if __name__ == "__main__":
    app.run()